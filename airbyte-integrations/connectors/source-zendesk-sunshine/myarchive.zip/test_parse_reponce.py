import os
import requests
import json
import datetime
import warnings
import random
import itertools

def GenerateRandomString(length = 7):
    s = ""
    for i in range(length):
        #s+=chr(random.randint(97,122)) #choice(range(97,123)))
        s+=chr(random.choice(list(itertools.chain(range(97, 122), range(48,58)))))
    return s


surveymonkey_token = 'wD.rd9HKenA2QV2Z2zV.kA.5LGw0xxi.h3r2.XtWSvRu7.d1e1l8VFG1wqfjZJD6tUxlCIcEu6CTtqYbgvJXkasM8XqM8J.3ThfJtH73AjD5VcjppYA5nMc7U0amNWUM'

class JsonSchemaWriter:

    @classmethod
    def create_schemas(
            self,
            data: dict,
            folder= os.path.abspath('schemas')
            ):
        if not os.path.exists(folder):
            os.mkdir(folder)
        
        for k, v in data.items():
            filename = os.path.join(folder, k + ".json")
            with open(filename, 'w') as file:
                json.dump(v, file, indent=2)
                
    @classmethod
    def construct_configured_catalog(
            self,
            data: dict,
            outfile="configured_catalog.json"):
        self.root = {"streams": []}
        for k,v in data.items():
            stream = {}
            stream["stream"] = {}
            stream["stream"]["name"] = k
            stream["stream"]["json_schema"] = v
            stream["stream"]["supported_sync_modes"] = ["full_refresh", "incremental"]
            stream["stream"]["source_defined_cursor"] = True
            stream["stream"]["default_cursor_field"] = []
            stream["sync_mode"] = "incremental"
            stream["cursor_field"] = []
            stream["destination_sync_mode"] = "append"
            self.root["streams"].append(stream)
            
        json.dump(self.root, open(outfile, 'w'), indent=2)
            
        
    def __init__(self, data):
        self.data = data
        self.mapping = {
            int: "integer",
            str: "string",
            bool: "boolean",
            float: "number",
        }


    def construct_schema(self):
        self.schema = self.process_dict(self.data)


    def process_dict(self, dict_value):
        head = {}
        head["type"] = "object"
        #head["title"] = ""
        #head["description"] = ""
        head["properties"] = {}
        for k,v in dict_value.items():
            if v is None:
                print(k, '=>', type(v))
                #raise ValueError('UNHANDLED NoneType!')
                head["properties"][k] = {}
                head["properties"][k]["type"] = "string"
                warnings.warn('REPLACE None in `%s` field'%k)
            elif type(v) in self.mapping:
                head["properties"][k] = {}
                head["properties"][k]["type"] = self.mapping[type(v)]
            elif type(v)==datetime.datetime:
                head["properties"][k] = {}
                head["properties"][k]["type"] = "string"
                head["properties"][k]["format"] = "date-time"
            elif type(v)==list:
                list_value = self.process_list(v)
                if not list_value["items"]:
                    del list_value["items"]
                head["properties"][k] = list_value
            elif type(v)== dict:
                dict_value = self.process_dict(v)
                if not dict_value['properties']:
                    del dict_value['properties']
                head["properties"][k] = dict_value
            else:
                print(k, '=>', type(v))
                raise NotImplementedError('unknown')
        return head

    def process_list(self, list_value):
        head = {}
        head["type"] = "array"
        #head["title"] = ""
        #head["description"] = ""
        head["items"] = {}
        if not list_value:
            head["items"]["type"] = "string"
            return head
        item_type = type(list_value[0])
        if item_type is None:
            print('in_proc_list', list_value)
            raise ValueError('UNHANDLED NoneType!')
        elif item_type in self.mapping:
            head["items"]["type"] = self.mapping[item_type]
        elif item_type==datetime.datetime:
            head["items"]["type"] = "string"
            head["items"]["format"] = "date-time"
        elif item_type==list:
            list_value = self.process_list(list_value[0])
            if not list_value["items"]:
                del list_value["items"]
            head["items"] = list_value
        elif item_type==dict:
            dict_value = self.process_dict(list_value[0])
            if not dict_value['properties']:
                del dict_value['properties']
            head["items"] = dict_value
        else:
            print(item_type)
            raise NotImplementedError('unknown')
        return head


def SurveyMonkey():
    session = requests.Session()
    session.headers['Content-Type'] = 'application/json'
    session.headers['Authorization'] = 'Bearer %s'%token
    base_url = 'https://api.surveymonkey.com/v3/'

    lists = session.get(base_url + "lists")
    lists = lists.json()["lists"]

    campaigns = session.get(base_url + "campaigns")
    campaigns = campaigns.json()["campaigns"]

    activity = session.get(base_url + f"reports/{campaigns[0]['id']}/email-activity")
    activity = activity.json()["emails"]

    lists_schema = JsonSchemaWriter(data=lists[0])
    lists_schema.construct_schema()
    json.dump(lists_schema.schema, open('listiki.json', 'w'), indent=4)
    campaigns_schema = JsonSchemaWriter(data=campaigns[0])
    campaigns_schema.construct_schema()
    json.dump(campaigns_schema.schema, open('campaniki.json', 'w'), indent=4)
    activity_schema = JsonSchemaWriter(data=activity[0])
    activity_schema.construct_schema()
    json.dump(activity_schema.schema, open('ativiki.json', 'w'), indent=4)

    configured_data = {
        "campaigns": campaigns_schema.schema,
        "lists": lists_schema.schema,
        "email_activity": activity_schema.schema
    }
    JsonSchemaWriter.construct_configured_catalog(configured_data)


def save_schema(schema, path, indent=2):
    json.dump(
        schema,
        open(path, 'w'),
        indent=indent
    )


if __name__ == "__main__":
    api_token = "H30X4lVXYI4oMNRKoQpJpFjqj09ysS1GzGuV4pdN"
    subdomain = "d3v-airbyte"
    email = "integration-test@airbyte.io"
    session = requests.Session()
    session.auth = (f'{email}/token', api_token)
    session.headers["Content-Type"] = "application/json"
    base_url = f"https://{subdomain}.zendesk.com/api/sunshine/"

    # Elements and Elements stats
    #stats = session.get(base_url + "/api/element/stats/")
    # metadata field

        
    if True:
        obj_types = session.get(base_url + 'objects/types')
        key1 = obj_types.json()['data'][0]
        obj_types_writer = JsonSchemaWriter(data=key1)

        obj_records = session.get(base_url + 'objects/records', params={'type': key1['key']})
        obj_records_writer = JsonSchemaWriter(data=obj_records.json()['data'][0])

        rel_types = session.get(base_url + 'relationships/types')
        rel1 = rel_types.json()['data'][0]
        rel_types_writer = JsonSchemaWriter(data=rel1)

        rel_records = session.get(base_url + 'relationships/records', params={'type': rel1['key']})
        rel_records_writer = JsonSchemaWriter(data=rel_records.json()['data'][0])
        
        policies = session.get(base_url + f'objects/types/{key1["key"]}/permissions')
        policies_writer = JsonSchemaWriter(data=policies.json()['data'])

        jobs = session.get(base_url + 'jobs')
        jobs_writer = JsonSchemaWriter(data=jobs.json()['data'][0])

        limits = session.get(base_url + 'limits')
        limits_writer = JsonSchemaWriter(data=limits.json()['data'][0])

        writers = [i for i in globals() if i.endswith('_writer')]
        for writer in writers:
            eval(writer).construct_schema()
        configured_data = {
            "object_types": obj_types_writer.schema,
            "object_records": obj_records_writer.schema,
            "relationship_types": rel_types_writer.schema,
            "relationship_records": rel_records_writer.schema,
            "policies": policies_writer.schema,
            "jobs": jobs_writer.schema,
            "limits": limits_writer.schema,
        }
        JsonSchemaWriter.construct_configured_catalog(configured_data)
        JsonSchemaWriter.create_schemas(configured_data)
   
    
