#
# Copyright (c) 2021 Airbyte, Inc., all rights reserved.
#

from .destination import Destination

__all__ = ["Destination"]
