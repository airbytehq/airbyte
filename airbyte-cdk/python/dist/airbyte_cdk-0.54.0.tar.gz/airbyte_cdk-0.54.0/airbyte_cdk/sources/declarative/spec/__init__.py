#
# Copyright (c) 2023 Airbyte, Inc., all rights reserved.
#

from airbyte_cdk.sources.declarative.spec.spec import Spec

__all__ = ["Spec"]
